#!/usr/bin/perl
use strict;
use warnings;
#S.Hird: shird1@tigers.lsu.edu
#1 Dec 2012
#this script discards the burn-in of, thins and combines output files from *BEAST

##burnin is the number of steps to be discarded as burn-in
##thinning is the interval at which to subsample MCMC steps for downstream analysis. 10k steps takes quite a while to analyze and may not be necessary. 

#Read the files in a directory
print "put directory here AND DELETE SPACE AFTER NAME: ";
my $dirname = <STDIN>;
chomp $dirname;
opendir(DIR, $dirname) or die "can't opendir $dirname: $!";
my @allFiles = readdir(DIR);
chomp (@allFiles);
close (DIR);

print "Enter number of samples to be discraded as burn-in: ";
my $burnin = <STDIN>; #1000;
print "Enter thinning interval to subsample the posterior: ";
my $thinning = <STDIN>; #10;

mkdir "$dirname/combined";

my $outlogName = "$dirname/combined/combined.log";
my $treeStatesValue;
my @treeStates= ();
my %current = ();
my $logStatesValue;
my $logCount=0;

my @allFilesSorted = sort(@allFiles);
#print(@allFilesSorted);

#for each file in the directory, determine if it is a .trees or .log file, then do something
foreach my $i (@allFilesSorted){
	if ($i =~ m/.trees/){ 
		@treeStates=(); #clear treeStates array
		print "THIS IS $i\n";
		my @nameSplit = split(/\./, $i); #split the file name at the periods
		print "this is nameSplit-2 $nameSplit[-2]\n";
		if (exists ($current{"$nameSplit[-2]"})){ #if the name right before .trees is already in the name hash
			print "$nameSplit[-2] in hash already.\n";
			open FILE, "<", "$dirname/$i" or die $!;
			open OUTPUT, ">>", "$dirname/combined/$current{$nameSplit[-2]}[0]" or die $!;
			my $semicolons = 0;
			while (<FILE>){ #read through the file, get through the header part by counting how many semicolons have been passed
				if ($semicolons < 6) {
					if ($_ =~ /;/){
						$semicolons++;
					}
				}
				else{ #once you've passed the header, push the lines onto the treeStates array
					push (@treeStates, $_);
				}	
			}
		print $#treeStates, "\n";
		$treeStatesValue = $#treeStates; #count total number of lines 
		for (my $count = $burnin; $count < $treeStatesValue; $count+=$thinning){ #discard burnin, print correctly thinned lines
			print OUTPUT $treeStates[$count];
		}				
	}	
		else { #if file name not in hash, put in hash and do same steps as above to file
			@treeStates=(); #clear treeStates array
			$current{$nameSplit[-2]}[0] = "$nameSplit[-2].combined.trees";
			print "hash initiated: $nameSplit[-2] $current{$nameSplit[-2]}[0]\n";
					open FILE, "<", "$dirname/$i" or die $!;
			open OUTPUT, ">>", "$dirname/combined/$current{$nameSplit[-2]}[0]" or die $!;
			my $semicolons = 0;
			while (<FILE>){
				if ($semicolons < 6) {
					print OUTPUT "$_";
					if ($_ =~ /;/){
						$semicolons++;
					}
				}
				else{
					push (@treeStates, $_);
				}	#	print $_
			}
			print $#treeStates, "\n";
			$treeStatesValue = $#treeStates;
			for (my $count = $burnin; $count < $treeStatesValue; $count+=$thinning){
			#	print "on count $count\n";
				print OUTPUT $treeStates[$count];
			}	
		}
	}
		
	elsif ($i =~ m/.log/){ #for the log files -
		open OUTLOG, ">>", "$outlogName" or die $!;
		open FILE2, "<", "$dirname/$i" or die $!;
		my @logStates=(); #clear logStates array
		my $lineCount=0;
		if ($logCount == 0){ #if this is the first log file
			while (<FILE2>){
				if ($lineCount<3){ #print header information to combined log file
					print OUTLOG "$_";
					$lineCount++;
				}
				else {
					push (@logStates, $_);
				}
			}
			$logStatesValue = ($#logStates+1);
			print $logStatesValue, "\n";
			for (my $count2 = $burnin; $count2 < $logStatesValue; $count2+=$thinning){ #burnin and thin
				print OUTLOG $logStates[$count2];
			}
		$logCount=1; #switch counter for log file
		}
		else{	#burnin and thin other log file(s)
			@logStates=(); #clear logStates array
			open FILE2, "<", "$dirname/$i" or die $!;
			my @file2 = <FILE2>;
			$logStatesValue = ($#file2+1);
			print $logStatesValue, "\n";
			for (my $count3 = (3+$burnin); $count3 < $logStatesValue; $count3+=$thinning){
				print OUTLOG $file2[$count3];
			}
		}
	}
	else {
		print "i did nothing\n"; #ignore all other files in directory
	}
}

#this is to add an "end;" to the end of the combined trees files
my $combineddir = "$dirname/combined";
opendir(COM, $combineddir) or die "can't opendir $combineddir: $!";
my @combinedFiles = readdir(COM);
chomp (@combinedFiles);
close (COM);

print @combinedFiles;

foreach my $ii (@combinedFiles){
	if ($ii =~ m/.trees/){
		open FILE3, ">>", "$combineddir/$ii" or die $!;
		print FILE3 "end;";
		close FILE3;
	}
}